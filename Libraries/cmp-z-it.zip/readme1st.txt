*To use this project in Visual Basic*

***16-BIT RELEASE***
(WOW! 16-Bit version released as class module and 16-bit DLL
module. ZLIB16.DLL)

Simply place the ZLIB.DLL file into the common Windows system
directory.

If using NT, place it into the \System32 directory.

(The system32 directory is on NT, the system directory is on Win95)

(ie, C:\WINDOWS\SYSTEM)

Then just run the VBG file. This file contains both the control
source project and the demonstration project.

(the ZLIB.DLL is written by the zLib authors - it is a C DLL)

I give my personal honour and credit to the zLib authors for this
little beauty.

I wrote the interface and some helper code, so that VB programmers
can make use of it.

--- *important notes* ---

VB4 Users, an OCX has been compiled within this project. But there
is no demo, unfortunately. So you might just like to go and edit
the .FRM file, and just cut out the code from there, cuz it's all
in ascii text. So I hope you don't have too much trouble.

It requires the VB5 runtime libraries, though. So I guess you need
them too. Download them from Microsoft's web site.

--- *+* ---

It's free! Feel free to modify the source. Change it if you wish, and
incorporate it into your own applications.

Most of all, it's free. It will cost you absolutely nothing.

Oh yeah, and no royalties either.

*** DISCLAIMER ***

WARNING:

I make absolutely no warranties as to the use and performance of this
software herein. I will not be liable for any loss or damage caused by
the use of, or inability to use, this software.

This software has been tested, and should work. But I will make no 
guarantee of it.

So, be reasonable. Do not try to use 1 gigabyte byte arrays, do not
try to use a 1 gigabyte string. It just may not work, as most
computers have only roughly 32 megabytes of RAM. So hoping to do it
with 1000 megabytes will only bring disappointment unless you
have 1 gigabyte of RAM.

*** END OF DISCLAIMER ***


Have a nice day.

:-)

Benjamin Dowse,
DowseWare
Software Solutions